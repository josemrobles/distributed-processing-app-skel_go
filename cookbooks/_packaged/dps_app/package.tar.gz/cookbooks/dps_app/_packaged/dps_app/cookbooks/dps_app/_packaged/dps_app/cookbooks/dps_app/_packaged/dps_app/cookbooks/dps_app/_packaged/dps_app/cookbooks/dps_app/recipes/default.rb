#
# Cookbook Name:: dps_app
# Recipe:: default
#
# Copyright (C) 2016 Jose M. Robles
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'apt::default'
